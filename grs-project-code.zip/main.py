def main():
    print("Hello from grs-project-last-phase!")


if __name__ == "__main__":
    main()
