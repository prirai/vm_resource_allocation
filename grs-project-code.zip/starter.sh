virsh start grs-project-1
virsh start grs-project-2
virsh start grs-project-3